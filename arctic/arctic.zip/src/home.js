import React from 'react'
import * as bs from 'react-bootstrap'
import PRODUCTS from './products'
import ProductCard from './productcard'
import { useRouteMatch } from 'react-router-dom'


function Home(props) {    
    let match = useRouteMatch('/category/:id')
    let newObject = {}
    if (match != null) {
        //console.log(match.params.id)
        Object.values(PRODUCTS).map((p) => {
            if (p.category === match.params.id) {
                newObject[p.id] = p
            }
            return newObject
        })
    }
    else {
        newObject = PRODUCTS
    }
        
    return (
        <bs.Container fluid className="p-0">            
            <bs.Row noGutters style={{ padding: "2rem 0"}}>
                
                {Object.values(newObject).map((p, idx) => {
                    return (
                        <ProductCard key={idx} p={p}/>                        
                    )                    
                })}                

            </bs.Row>

            <bs.Row noGutters style={{ padding: "4rem 0" }} className="bg-info shadow">
                <bs.Col>
                    <div className="px-5 text-center text-white" sytle={{ fontSize: "1.5rem" }}>
                        Et incididunt duis fugiat consequat et duis eiusmod nostrud ex aliquip pariatur irure.
                    </div>
                </bs.Col>
            </bs.Row>
        </bs.Container>
        
    )
}
export default Home