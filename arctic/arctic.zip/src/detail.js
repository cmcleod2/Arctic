import React, { useState } from 'react'
import * as bs from 'react-bootstrap'
import PRODUCTS from './products'
import { Link, useRouteMatch } from 'react-router-dom'

function Detail(props) {
    let match = useRouteMatch('/product/:id')

    let product = []
    product = Object.values(PRODUCTS).find(x => x.id === match.params.id)
    let [pic, setPic] = useState(`-1`)
    
    if (!product) {
        return (
            <bs.Container className="text-center" style={{ padding: "3rem 0"}}>
                <h1>Not Found</h1>
            </bs.Container>            
        )
    }
    else {
        return (
        
            <bs.Container>            
                <bs.Row style={{ padding: "3rem 0"}}>
                    <bs.Col md='8'>
                        <h1>{product.name}</h1>
                        <h2>${product.price.toFixed(2)}</h2>
                        <p>{product.description}</p>
                    </bs.Col>
                    <bs.Col md='4'>
                        <img src={`/media/products/${product.filename}${pic}.png`} alt={`${product.name}`} style={{ height: "300px", width: "300px"}}></img>
                    </bs.Col>
                </bs.Row>
                <bs.Row style={{ padding: "0rem 0"}}>
                    <bs.Col md='8'>
                    <Link to={`/`} className="btn btn-dark">Back to List</Link>
                    </bs.Col>
                    <bs.Col md='4'>
                        <img 
                            onMouseEnter={() => setPic(`-1`)} 
                            src={`/media/products/${product.filename}-1.png`} 
                            alt={`${product.name}`} 
                            style={{ height: "30px", width: "30px"}}>
                        </img> &nbsp;
                        <img 
                            onMouseEnter={() => setPic(`-2`)}
                            src={`/media/products/${product.filename}-2.png`} 
                            alt={`${product.name}2`} 
                            style={{ height: "30px", width: "30px"}}>
                        </img> &nbsp;
                        <img 
                            onMouseEnter={() => setPic(`-3`)}
                            src={`/media/products/${product.filename}-3.png`} 
                            alt={`${product.name}3`} 
                            style={{ height: "30px", width: "30px"}}>
                        </img> &nbsp;
                        <img 
                            onMouseEnter={() => setPic(`-4`)}
                            src={`/media/products/${product.filename}-4.png`} 
                            alt={`${product.name}4`} 
                            style={{ height: "30px", width: "30px"}}>
                        </img>
                    </bs.Col>
                </bs.Row>
            </bs.Container>
        )
    }

    
}
export default Detail