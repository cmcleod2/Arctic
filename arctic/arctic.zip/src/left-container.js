import React from 'react'
import * as bs from 'react-bootstrap'
import { Link } from 'react-router-dom'
import PRODUCTS from './products'

function LeftContainer (props) {

    const categories = {}
    let count = 0

    for (const p of Object.values(PRODUCTS)) {
        
        categories[p.category] = (categories[p.category] || 0) + 1
        count++
    }

    //console.log(categories)

    return (
        <bs.Container>
            <h2>Filters</h2>
            <hr />            
            <bs.Nav defaultActiveKey="/" className="flex-column">
                <Link to="/" className="nav-link">All Products ({count})</Link>
                
                {Object.entries(categories).map(([cat, count]) => (
                    
                    <Link to={`/category/${cat}`} key={cat} className="nav-link">{cat} ({count})</Link>
                                            
                ))}
                
            </bs.Nav>
        </bs.Container>  
    )
}
export default LeftContainer