import React from 'react'
import * as bs from 'react-bootstrap'

function RightContainer (props) {
    return (
        <bs.Container>
            <h2>Recent:</h2>            
            
        </bs.Container>
    )
}
export default RightContainer